import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import { FontAwesome5 } from '@expo/vector-icons';

export default function Boat(props) {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <FontAwesome5
          name="ship"
          size={24}
          color="#ffffff"
          style={styles.icon}
        />

        <Text style={styles.name}>
          {props.name}
        </Text>
      </View>

      <Text style={styles.description}>
        {props.description}
      </Text>

      <Image
        source={props.picture}
        style={styles.image}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    borderRadius: 15,
    marginBottom: 20,
    overflow: 'hidden',

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 6,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',

    backgroundColor: '#0A5E8A',
    padding: 15,
  },

  icon: {
    marginRight: 10,
  },

  name: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    flex: 1,
  },

  description: {
    fontSize: 15,
    color: '#444',
    textAlign: 'center',
    padding: 15,
    lineHeight: 22,
  },

  image: {
    width: '100%',
    height: 220,
    resizeMode: 'cover',
  },
});