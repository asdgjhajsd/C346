import React, { useState } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  Button,
  Alert,
  ScrollView,
} from "react-native";
import { Picker } from "@react-native-picker/picker";

export default function App() {
  const [answer1, setAnswer1] = useState("");
  const [answer2, setAnswer2] = useState("");
  const [answer3, setAnswer3] = useState("");

  const submitAnswers = () => {
    let score = 0;

    if (answer1 === "Elephant") score++;
    if (answer2 === "Leopard") score++;
    if (answer3 === "Kingfisher") score++;

    Alert.alert("Quiz Result", `You got ${score} correct answer(s)!`);
  };

  return (
  <ScrollView style={styles.container}>
    <Text style={styles.title}>Animal Quiz</Text>

    <View style={styles.card}>
      <Image
        source={require("./img/elephant.jpg")}
        style={styles.image}
      />

      <Text style={styles.question}>
        What animal is this?
      </Text>

      <Picker
        style={styles.picker}
        selectedValue={answer1}
        onValueChange={(itemValue) => setAnswer1(itemValue)}
      >
        <Picker.Item label="Select an answer" value="" />
        <Picker.Item label="Elephant" value="Elephant" />
        <Picker.Item label="Lion" value="Lion" />
        <Picker.Item label="Tiger" value="Tiger" />
      </Picker>
    </View>

    <View style={styles.card}>
      <Image
        source={require("./img/George.jpg")}
        style={styles.image}
      />

      <Text style={styles.question}>
        What animal is this?
      </Text>

      <Picker
        style={styles.picker}
        selectedValue={answer2}
        onValueChange={(itemValue) => setAnswer2(itemValue)}
      >
        <Picker.Item label="Select an answer" value="" />
        <Picker.Item label="Leopard" value="Leopard" />
        <Picker.Item label="Cheetah" value="Cheetah" />
        <Picker.Item label="Jaguar" value="Jaguar" />
      </Picker>
    </View>

    <View style={styles.card}>
      <Image
        source={require("./img/kingfisher.jpg")}
        style={styles.image}
      />

      <Text style={styles.question}>
        What animal is this?
      </Text>

      <Picker
        style={styles.picker}
        selectedValue={answer3}
        onValueChange={(itemValue) => setAnswer3(itemValue)}
      >
        <Picker.Item label="Select an answer" value="" />
        <Picker.Item label="Stork" value="Stork" />
        <Picker.Item label="Kingfisher" value="Kingfisher" />
        <Picker.Item label="Parrot" value="Parrot" />
      </Picker>
    </View>

    <View style={styles.buttonContainer}>
      <Button
        title="Submit Answers"
        onPress={submitAnswers}
        color="#1E88E5"
      />
    </View>
  </ScrollView>
);
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#EAF4FC",
    padding: 15,
    marginTop: 40,
  },

  title: {
    alignSelf: "center",
    fontSize: 32,
    fontWeight: "bold",
    textAlign: "center",
    color: "#1565C0",
    marginBottom: 20,
  },

  card: {
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 15,
    padding: 12,
    marginBottom: 25,

    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,

    elevation: 5,
  },

  image: {
    width: "95%",
    height: 220,
    borderRadius: 12,
    resizeMode: "cover",
    marginBottom: 10,
  },

  question: {
    backgroundColor: "#1976D2",
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
  },

  picker: {
    width: "100%",
  },

  buttonContainer: {
    marginBottom: 40,
  },
});