import React, { useState } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  Button,
  Alert,
  ScrollView,
} from "react-native";
import { Picker } from "@react-native-picker/picker";

export default function App() {
  const [answer1, setAnswer1] = useState("");
  const [answer2, setAnswer2] = useState("");
  const [answer3, setAnswer3] = useState("");

  const submitAnswers = () => {
    let score = 0;

    if (answer1 === "Elephant") score++;
    if (answer2 === "Leopard") score++;
    if (answer3 === "Kingfisher") score++;

    Alert.alert("Quiz Result", `You got ${score} correct answer(s)!`);
  };

  return (
    <ScrollView style={styles.container}>
      {/* Question 1 */}
     <Image
  source={require("./assets/elephant.jpg")}
  style={styles.image}
/>


      <Text>What animal is this?</Text>

      <Picker
        selectedValue={answer1}
        onValueChange={(itemValue) => setAnswer1(itemValue)}
      >
        <Picker.Item label="Select an answer" value="" />
        <Picker.Item label="Elephant" value="Elephant" />
        <Picker.Item label="Lion" value="Lion" />
        <Picker.Item label="Tiger" value="Tiger" />
      </Picker>

      {/* Question 2 */}
      <Image
        source={require("./assets/George.jpg")}
        style={styles.image}
      />

      <Text>What animal is this?</Text>

      <Picker
        selectedValue={answer2}
        onValueChange={(itemValue) => setAnswer2(itemValue)}
      >
        <Picker.Item label="Select an answer" value="" />
        <Picker.Item label="Leopard" value="Leopard" />
        <Picker.Item label="Cheetah" value="Cheetah" />
        <Picker.Item label="Jaguar" value="Jaguar" />
      </Picker>

      {/* Question 3 */}
      <Image
        source={require("./assets/kingfisher.jpg")}
        style={styles.image}
      />

      <Text>What animal is this?</Text>

      <Picker
        selectedValue={answer3}
        onValueChange={(itemValue) => setAnswer3(itemValue)}
      >
        <Picker.Item label="Select an answer" value="" />
        <Picker.Item label="Stork" value="Stork" />
        <Picker.Item label="Kingfisher" value="Kingfisher" />
        <Picker.Item label="Parrot" value="Parrot" />
      </Picker>

      <Button title="Submit Answers" onPress={submitAnswers} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 10,
    marginTop: 40,
  },
  image: {
    width: "100%",
    height: 200,
    resizeMode: "cover",
    marginTop: 10,
  },
});